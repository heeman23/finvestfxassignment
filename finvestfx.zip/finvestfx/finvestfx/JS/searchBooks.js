


function getbook() {
var searchValue=$("#bookName").val();
$("#displayImage").empty();
$("#displayinfo").find("tbody").empty();
    $.ajax({
        type: "get",
        // dataType: "JSON",

        async: false,
        url: "https://www.googleapis.com/books/v1/volumes?q="+searchValue,
        crossDomain: true,

        success: function (data) {
            $.each(data,function(key,value) {
                // console.log(key + ":" + value)

                if (key === "items") {

                    $.each(value, function (key1, value1) {

                       if(key1===0){
                           $.each(value1, function (key2, value2) {
                               // console.log(key2 + ":" +value2)

                               if(key2==="volumeInfo"){
$.each(value2,function(key3,value3){
    console.log(key3 + ":" +value3)
    if(key3==="imageLinks"){
var displayimg='<img src='+value3.thumbnail+' class="img-rounded" alt="Cinque Terre" width="304" height="236">'
$("#displayImage").append(displayimg);
    }
    if(key3==="title") {
        $("#displayinfo").find("tbody").append("<tr><td>Title:</td><td>"+ value3+ "</td></tr>");
    }if(key3==="authors") {
        $("#displayinfo").find("tbody").append("<tr><td>authors:</td><td>"+ value3 + "</td></tr>");
    }
    if(key3==="publishedDate") {
        $("#displayinfo").find("tbody").append("<tr><td>publishedDate:</td><td>"+ value3 + "</td></tr>");
    }
if(key3==="description") {
        $("#displayinfo").find("tbody").append("<tr><td>description:</td><td>"+ value3 + "</td></tr>");
    }



})


                               }


                           })



                       }





                    });
                }

            });





        },
        error: function (jqXHR, error) {

        },


    });
}