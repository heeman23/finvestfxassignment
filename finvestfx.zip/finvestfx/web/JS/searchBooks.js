
var list = [];

function addbookRepo(element) {
    var bookTitle = $("#title").next().html();
    list.push(bookTitle);
    localStorage.setItem("bookList", list);
//  alert(localStorage.getItem("bookList"));
}

function favouriteList() {
    var List = localStorage.getItem("bookList");
    var bookList = List.split(",");
    $("#favouritelist").find("ul").css("display", "inline-block");
    for (var i = 0; i < bookList.length; i++) {
        console.log(bookList[i])
        if ((jQuery.inArray(bookList[i], bookList)) > -1)
        {
            alert("ss")

            $("#favouritelist").find("ul").append('<li class="list-group-item active">' + bookList[i] + '</li>');
        }

    }


}
function getbook() {
    var searchValue = $("#bookName").val();
    $("#displayImage").empty();
    $("#displayinfo").find("tbody").empty();
    $.ajax({
        type: "get",
        // dataType: "JSON",

        async: false,
        url: "https://www.googleapis.com/books/v1/volumes?q=" + searchValue,
        crossDomain: true,

        success: function (data) {
            $.each(data, function (key, value) {
                // console.log(key + ":" + value)

                if (key === "items") {

                    $.each(value, function (key1, value1) {

                        if (key1 === 0) {
                            $.each(value1, function (key2, value2) {
                                // console.log(key2 + ":" +value2)

                                if (key2 === "volumeInfo") {
                                    $.each(value2, function (key3, value3) {
                                        console.log(key3 + ":" + value3)
                                        if (key3 === "imageLinks") {
                                            var displayimg = '<img src=' + value3.thumbnail + ' class="img-rounded" alt="Cinque Terre" width="304" height="236">'
                                            $("#displayImage").append(displayimg);
                                        }
                                        if (key3 === "title") {
                                            $("#displayinfo").find("tbody").append("<tr><td id=" + key3 + ">Title:</td><td>" + value3 + "</td></tr>");
                                        }
                                        if (key3 === "authors") {
                                            $("#displayinfo").find("tbody").append("<tr><td>authors:</td><td>" + value3 + "</td></tr>");
                                        }
                                        if (key3 === "publishedDate") {
                                            $("#displayinfo").find("tbody").append("<tr><td>publishedDate:</td><td>" + value3 + "</td></tr>");
                                        }
                                        if (key3 === "description") {
                                            $("#displayinfo").find("tbody").append("<tr><td>description:</td><td>" + value3 + "</td></tr>");
                                        }



                                    })


                                }


                            })



                        }





                    });
                }

            });




            $("#gluphiconButon").css("display", "inline-block")
        },
        error: function (jqXHR, error) {

        },

    });
}